Six user-approved original transparent PNG images, unmodified. Preserve RGBA and native resolution. Assign unique species IDs after checking existing collection to prevent duplicates.
